package com.trilio.client

import java.net.URI
...
class TrilioVaultClient {
    ...
}